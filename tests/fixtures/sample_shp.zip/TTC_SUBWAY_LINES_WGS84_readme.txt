TTC_SUBWAY_LINES_WGS84_readme
 

Column name  (Description)
======================================
OBJECTID = OBJECTID  (Unique Identifier)
ROUTE_NAME = ROUTE_LONG_NAME  (Full name of a route)
